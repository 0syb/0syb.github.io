date=document.getElementById("date");
if (1 == 1)
{
 date.innerHTML = Date();
}